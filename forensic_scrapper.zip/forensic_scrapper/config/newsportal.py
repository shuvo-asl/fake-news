NEWSPORTAL_CONFIG = {
    "prothom_alo": {
            "name": "Prothom Alo",
            "maximum_load_more_clicks": 5,
            "editions":{
                "bangla":{
                    "url": "https://www.prothomalo.com/",
                    "topics": [
                        "topic/জাহাঙ্গীরনগর-বিশ্ববিদ্যালয়"
                    ]
                },
                "english":{
                    "url": "https://en.prothomalo.com/",
                    "topics": [
                        "topic/Jahangirnagar-University"
                    ]
                }
            }
        }
}