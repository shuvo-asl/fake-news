SELENIUM_CONFIG = {
    "headless": False,
    "window_size":"1920, 1080",
    "timeout": 30,
    "wait_timeout": 10,
}

# File paths
MEDIA_ROOT = 'media/'
MEDIA_DIRS = {
    'images': 'images/',
    'videos': 'videos/',
    'documents': 'documents/',
    'audio': 'audio/',
}