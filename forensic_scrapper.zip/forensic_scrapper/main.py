# import third party libraries
import logging
import logging.config
# local imports
from scrappers.prothom_alo import ProthomAloScrapper
from config.logger import LOGGING_CONFIG

# Configure logging
logging.config.dictConfig(LOGGING_CONFIG)

def main():
    try:
        scrapper = ProthomAloScrapper()
        scrapper.start()
    except Exception as e:
        logging.error(f"An error occurred: {e}")
    finally:
        scrapper.end()


if __name__ == "__main__":
    main()