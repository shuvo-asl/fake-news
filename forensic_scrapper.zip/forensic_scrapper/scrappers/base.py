# third party imports
from abc import ABC, abstractmethod
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import logging

# local imports
from config.app import SELENIUM_CONFIG, MEDIA_ROOT, MEDIA_DIRS
logger = logging.getLogger(__name__)

class ScrapperBase(ABC):

    def __init__(self):
        self.driver = self.__setup_driver()

    def __setup_driver(self):
        logger.info("Setting up Chrome WebDriver...")
        options = Options()

        if SELENIUM_CONFIG['headless']:
            options.add_argument('--headless')

        if not SELENIUM_CONFIG['headless']:
            options.add_experimental_option('detach',True)

        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        # Standard options for stability in various environments
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        # Get window size from config or use a default
        window_size = SELENIUM_CONFIG.get('window_size', "1920,1080") 

        # Add the argument correctly formatted as a single string
        options.add_argument(f"--window-size={window_size}")
        options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

        try:
            driver = webdriver.Chrome(options=options)
            logger.info("Chrome WebDriver setup complete.")
            return driver
        except Exception as e:
            logger.error(f"Error setting up Chrome WebDriver: {e}")
            raise
    
    def _close_driver(self):
        if self.driver:
            logger.info("Closing Chrome WebDriver...")
            self.driver.quit()
            logger.info("Chrome WebDriver closed.")
    
    @abstractmethod
    def start(self):
        raise NotImplementedError("Subclasses must implement this method")
    @abstractmethod
    def fetch_all_topics(self):
        raise NotImplementedError("Subclasses must implement this method")
    @abstractmethod
    def fetch_topic_page(self, topic, language):
        raise NotImplementedError("Subclasses must implement this method")
    # @abstractmethod
    # def parse(self, content):
    #     raise NotImplementedError("Subclasses must implement this method")
    # @abstractmethod
    # def download_media_files(self):
    #     raise NotImplementedError("Subclasses must implement this method")
    # @abstractmethod
    # def download_media_file(self, file_url, type):
    #     raise NotImplementedError("Subclasses must implement this method")
    


    def display_config(self):
        print(self.config)