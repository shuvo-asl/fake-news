# third party imports
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import logging
from selenium.common.exceptions import TimeoutException
# local imports
from scrappers.base import ScrapperBase
from config.newsportal import NEWSPORTAL_CONFIG
from config.app import SELENIUM_CONFIG

logger = logging.getLogger(__name__)


class ProthomAloScrapper(ScrapperBase):
    def __init__(self):
        super().__init__()
        self.config = NEWSPORTAL_CONFIG["prothom_alo"]
        self.articles = []

    def start(self):
        print("Starting Prothom Alo Scrapper")
        # Fetch all topics
        self.articles = self.fetch_all_topics()
        print(self.articles)
        print(f"Total articles fetched: {len(self.articles)}")

    def end(self):
        self._close_driver()
        print("Prothom Alo Scrapper finished.")
    
    def fetch_all_topics(self):
        for edition, details in self.config['editions'].items():
            url = details['url']
            topics = details['topics']
            for topic in topics:
                topic_url = f"{url}{topic}"
                print(f"Fetching articles from: {topic_url}-{edition}")
                self.articles.extend(self.fetch_topic_page(topic_url,edition))
    def _normalize_url(self, link: str, base_url: str) -> str:
        """Constructs an absolute URL from a relative link."""
        if link.startswith('//'):
            return "https:" + link
        if link.startswith('/'):
            return base_url + link
        return link
    
    def _click_load_more(self) -> bool:
        """
        Waits for and clicks the 'Load More' button using explicit waits.
        Returns True if clicked, False otherwise.
        """
        try:
            # A more specific XPath selector that finds a button/div with the relevant text.
            # This works for both Bengali ("আরও দেখুন") and English ("Load More").
            load_more_xpath = "//*[contains(text(), 'আরও দেখুন') or contains(text(), 'Load More')]"

            load_more_button = WebDriverWait(self.driver, SELENIUM_CONFIG['wait_timeout']).until(
                EC.element_to_be_clickable((By.XPATH, load_more_xpath))
            )
            # Use JavaScript click to avoid potential interception by other elements
            self.driver.execute_script("arguments[0].click();", load_more_button)
            logger.info("Clicked 'Load More' button.")
            return True
        except TimeoutException:
            logger.info("No 'Load More' button was found or it was not clickable.")
            return False
        except Exception as e:
            logger.warning(f"An unexpected error occurred while clicking 'Load More': {e}")
            return False

    def fetch_topic_page(self, topic_url,language):

        logger.info(f"Starting to scrape {language} site: {topic_url}")
        self.driver.get(topic_url)

        try:
            WebDriverWait(self.driver, SELENIUM_CONFIG['wait_timeout']).until(
                lambda d: d.execute_script('return document.readyState') == 'complete'
            )
        except TimeoutException as e:
            logger.error(f"Main content area did not load on {topic_url}: {e}")
            return []
        
        # Click "Load More" until it's no longer present
        max_clicks = self.config['maximum_load_more_clicks']  # Safeguard against infinite loops
        for i in range(max_clicks):
            if not self._click_load_more():
                break
            logger.info(f"Load more click #{i + 1}")
        # Now that all content is loaded, parse with BeautifulSoup
        soup = BeautifulSoup(self.driver.page_source, 'html.parser')

        # Use specific selectors for each language
        if language == 'english':
            selector = 'a.title-link'
            newspaper_name = f'{self.config['name']} (English)'
        else: # Bengali
            selector = 'a.link_overlay' # This is a much more reliable selector
            newspaper_name = 'Prothom Alo (Bengali)'

        articles = []
        for a in soup.select(selector):
            title = a.get_text(strip=True)
            link = a.get('href')
            if title and link:
                # full_link = self._normalize_url(link, topic_url)
                articles.append({
                    'newspaper_name': newspaper_name,
                    'title': title,
                    'source_link': link
                })

        logger.info(f"Scraped {len(articles)} articles from {language} site.")
        return articles
    